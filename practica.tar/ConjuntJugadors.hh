/** @file ConjuntJugadors.hh @brief Especificació de la classe ConjuntJugadors. */
#ifndef _ConjuntTornejos_HH_
#define _ConjuntTornejos_HH_

#include "Jugador.hh"
#include "Classificacio.hh"

#ifndef NO_DIAGRAM  
#include <vector>
#include <algorithm>
#include <map>
#endif

using namespace std;

/** @class ConjuntJugadors.
 *  @brief Representa un conjunt de jugadors.
 * 
 * Consta principalment d'un diccionari on 
 * s'emmagatzemen els jugadors. També conté funcions per afegir-ne, esborrar-ne, 
 * modificar-ne en funció de resultats en un torneig, i algunes basiques de sortida.
 */
class ConjuntJugadors {

	public:
		
		/** @brief Contructora defecte: Iniciatilza un conjunt de jugadors buit.
		 * \pre Cert.
		 * \post Un conjunt de jugadors buit.
		 */
		ConjuntJugadors() {};

		/** @brief Afegir jugador: Afegeix un jugador al conjunt.
		 * \pre Un string no buit.
		 * \post True: s'ha afegit el jugador amb una puntuacio de zero.
		 * False: no s'ha afegit perque ja existia.
		 */
		bool afegir_jugador(string nom_jugador);

		/** @brief Borrar Jugador: Borra un jugador en funció d'un identificador.
		 * \pre string (nom del jugador).
		 * \post True: s'ha trobat el jugador i s'ha esborrat.
		 * 	False: no existeix el jugador.
		 */
		bool borrar_jugador(string nom_jugador);

		/** @brief Afegir Classificació: Afegeix els punts i estadistiques obtingudes en un torneig 
		 * per als jugadors que hi han participat.
		 * \pre Una classifició d'un torneig (c).
		 * \post S'afegeix els resultats de la classificació del torneig als jugadors corresponents.
		 */
		void afegir_classificacio(Classificacio &c);

		/** @brief Retirar Classificació: Retira els punts obtinguts en un torneig als jugadors corresponents.
		 * \pre Una classificació d'un torneig (c).
		 * \post Es retira els resultats d'aqeusta classificació al jugadors corresponents.
		 */
		void retirar_classificacio(Classificacio &c);
		
		/** @brief Consultar Ranking: Retorna el ranking.
		 * \pre Cert.
		 * \post Retorna el ranking actual.
		 */
		vector<pair<string, int> > consultar_ranking();

		/** @brief Escriure Ranking: Escriu el ranking del circuit al canal de sortida.
		 * \pre Cert.
		 * \post El ranking escrit.
		 */
		void escriure_ranking();

		/** @brief Escriure Jugadors: Llista els jugadors al canal de sortida.
		 * \pre Cert.
		 * \post Els jugadors al canal de sortida, ordenats alfabèticament.
		 */
		void escriure_jugadors();

		/** @brief Escriure Jugadors: Escriu les estadistiques d'un jugador al canal de sortida.
		 * \pre Un string (nom del jugador).
		 * \post True : Escriu les estadistiques del jugador al canal de sortida.
		 * False: No existeix el jugador.
		 */
		bool escriure_jugador(string nom_jugador);

		
    	void actualitzar_ranking();
    private:

    	/* Pre: cert */
    	/* Post: el vector jugadors esta ordenat representant un ranking */
    	void ordenar_ranking();

    	//int punts (string nom_jugador);

        /* Pre: cert */
        /* Post: informa del ranking als jugador */
        void informar_ranking();

        map<string, Jugador> jugadors;
        vector<pair<string, int> > ranking;
};

#endif
