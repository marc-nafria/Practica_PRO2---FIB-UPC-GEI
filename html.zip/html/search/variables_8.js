var searchData=
[
  ['sets_5fcontra_0',['sets_contra',['../struct_resultat.html#a105f60fff84e0c84665238f059a09b22',1,'Resultat::sets_contra()'],['../class_jugador.html#a6aa8967c1ff2f9ec0a0807bee6af7972',1,'Jugador::sets_contra()']]],
  ['sets_5ffavor_1',['sets_favor',['../struct_resultat.html#aaab0b2b778b7251a8b0e0a0426f44811',1,'Resultat::sets_favor()'],['../class_jugador.html#a73d2ec1d219e26af2139b284b6c124b6',1,'Jugador::sets_favor()']]]
];
