var searchData=
[
  ['partits_5fcontra_0',['partits_contra',['../struct_resultat.html#aca52912746cb59f55400107364a740c3',1,'Resultat']]],
  ['partits_5ffavor_1',['partits_favor',['../struct_resultat.html#a9d84f0247214721722337d36720e1184',1,'Resultat']]],
  ['practicà_20pro_202_3a_20gestió_20d_27un_20circuit_20de_20tennis_2',['Practicà Pro 2: Gestió d&apos;un circuit de Tennis',['../index.html',1,'']]],
  ['program_2ecc_3',['program.cc',['../program_8cc.html',1,'']]],
  ['punts_4',['punts',['../struct_resultat.html#ab81e13e65ea0d122d6836a1cead8f242',1,'Resultat']]],
  ['punts_5fper_5fnivell_5',['punts_per_nivell',['../struct_categoria.html#a73793e1a6f68e974972b0789f9a31e91',1,'Categoria']]]
];
