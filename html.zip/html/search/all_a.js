var searchData=
[
  ['node_0',['Node',['../struct_bin_tree_1_1_node.html',1,'BinTree&lt; T &gt;::Node'],['../struct_bin_tree_1_1_node.html#af45885e303875c018e89fa5c8b96bde0',1,'BinTree::Node::Node()']]],
  ['nom_1',['nom',['../struct_categoria.html#ad39955d54081f0d7f31db96909a4f6bf',1,'Categoria::nom()'],['../class_jugador.html#afd6bec98df8ebb3d2db3ef583a76cfa1',1,'Jugador::nom()']]],
  ['nova_5fclassificacio_2',['nova_classificacio',['../class_torneig.html#afe1a3cbcbb4e2088a04614b4544ecd9d',1,'Torneig']]]
];
