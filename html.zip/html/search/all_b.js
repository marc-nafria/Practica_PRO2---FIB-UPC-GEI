var searchData=
[
  ['ranking_0',['ranking',['../program_8cc.html#a85d32da86b41760a67aaa338741896b8',1,'program.cc']]],
  ['resultat_1',['Resultat',['../struct_resultat.html',1,'']]],
  ['retirar_5fresultat_2',['retirar_resultat',['../class_jugador.html#adf706a1f4a79da9495f47874c11810f5',1,'Jugador']]],
  ['right_3',['right',['../class_bin_tree.html#aff8e96651b27284c329667b5ad3e4d0b',1,'BinTree']]]
];
