var searchData=
[
  ['categoria_0',['Categoria',['../struct_categoria.html',1,'']]],
  ['categoria_1',['categoria',['../class_torneig.html#a4477c61eb5b2b1c365ba6d195e60fc0a',1,'Torneig']]],
  ['categoria_2ehh_2',['Categoria.hh',['../_categoria_8hh.html',1,'']]],
  ['categories_3',['categories',['../program_8cc.html#a1cd0d2f55ad04fff27a5c40a2d8b9ec4',1,'program.cc']]],
  ['classificacio_4',['Classificacio',['../class_classificacio.html',1,'']]],
  ['classificacio_2ecc_5',['Classificacio.cc',['../_classificacio_8cc.html',1,'']]],
  ['classificacio_2ehh_6',['Classificacio.hh',['../_classificacio_8hh.html',1,'']]],
  ['construir_5farbre_5femparellaments_7',['construir_arbre_emparellaments',['../class_torneig.html#aaee898ef9497d6727f975399e9c2cec4',1,'Torneig']]],
  ['consultar_5fclassificacio_8',['consultar_classificacio',['../class_classificacio.html#ad8ecec54f53d504f95f18dba9b96a531',1,'Classificacio']]],
  ['consultar_5fdarrera_5fclassificacio_9',['consultar_darrera_classificacio',['../class_torneig.html#a2fdf459665896c0bc542d6d9f1e40586',1,'Torneig']]],
  ['consultar_5fnom_5fcategoria_10',['consultar_nom_categoria',['../class_torneig.html#ad126d3be0c787e50ba49278acf5c8937',1,'Torneig']]],
  ['consultar_5fpunts_11',['consultar_punts',['../class_jugador.html#a9db8d3e750619e7723065d74baf96529',1,'Jugador']]],
  ['consultar_5franking_12',['consultar_ranking',['../class_jugador.html#a2b28e8d54fdc699ac9383f9b539e6119',1,'Jugador']]],
  ['copiar_5fclassificacio_13',['copiar_classificacio',['../class_classificacio.html#a5d2e4d797a1793ccbbec6f700a467b2d',1,'Classificacio']]]
];
