var searchData=
[
  ['consultar_5fclassificacio_0',['consultar_classificacio',['../class_classificacio.html#ad8ecec54f53d504f95f18dba9b96a531',1,'Classificacio']]],
  ['consultar_5fdarrera_5fclassificacio_1',['consultar_darrera_classificacio',['../class_torneig.html#a2fdf459665896c0bc542d6d9f1e40586',1,'Torneig']]],
  ['consultar_5fnom_5fcategoria_2',['consultar_nom_categoria',['../class_torneig.html#ad126d3be0c787e50ba49278acf5c8937',1,'Torneig']]],
  ['consultar_5fpunts_3',['consultar_punts',['../class_jugador.html#a9db8d3e750619e7723065d74baf96529',1,'Jugador']]],
  ['consultar_5franking_4',['consultar_ranking',['../class_jugador.html#a2b28e8d54fdc699ac9383f9b539e6119',1,'Jugador']]],
  ['copiar_5fclassificacio_5',['copiar_classificacio',['../class_classificacio.html#a5d2e4d797a1793ccbbec6f700a467b2d',1,'Classificacio']]]
];
