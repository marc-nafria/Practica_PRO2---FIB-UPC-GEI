var searchData=
[
  ['torneig_2ecc_0',['Torneig.cc',['../_torneig_8cc.html',1,'']]],
  ['torneig_2ehh_1',['Torneig.hh',['../_torneig_8hh.html',1,'']]]
];
