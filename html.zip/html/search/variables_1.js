var searchData=
[
  ['jocs_5fcontra_0',['jocs_contra',['../struct_resultat.html#a551c20855cfd9ba38b23f5a36756606d',1,'Resultat']]],
  ['jocs_5ffavor_1',['jocs_favor',['../struct_resultat.html#afdbe10c31ea6c47c7f8d8465749c75c9',1,'Resultat']]],
  ['jugadors_2',['jugadors',['../program_8cc.html#af06cd104b07890efd0af7b4a5ab8e84b',1,'program.cc']]]
];
