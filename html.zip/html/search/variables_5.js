var searchData=
[
  ['nom_0',['nom',['../struct_categoria.html#ad39955d54081f0d7f31db96909a4f6bf',1,'Categoria::nom()'],['../class_jugador.html#afd6bec98df8ebb3d2db3ef583a76cfa1',1,'Jugador::nom()']]],
  ['nova_5fclassificacio_1',['nova_classificacio',['../class_torneig.html#afe1a3cbcbb4e2088a04614b4544ecd9d',1,'Torneig']]]
];
