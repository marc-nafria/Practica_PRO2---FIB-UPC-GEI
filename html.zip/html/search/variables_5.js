var searchData=
[
  ['sets_5fcontra_0',['sets_contra',['../struct_resultat.html#a105f60fff84e0c84665238f059a09b22',1,'Resultat']]],
  ['sets_5ffavor_1',['sets_favor',['../struct_resultat.html#aaab0b2b778b7251a8b0e0a0426f44811',1,'Resultat']]]
];
