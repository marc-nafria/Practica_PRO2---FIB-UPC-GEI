var searchData=
[
  ['darrera_5fclassificacio_0',['darrera_classificacio',['../class_torneig.html#a08eb04b47bf8112e6153ea9b5d0daa14',1,'Torneig']]]
];
