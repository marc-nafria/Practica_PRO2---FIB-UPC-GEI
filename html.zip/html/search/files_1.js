var searchData=
[
  ['categoria_2ehh_0',['Categoria.hh',['../_categoria_8hh.html',1,'']]],
  ['classificacio_2ecc_1',['Classificacio.cc',['../_classificacio_8cc.html',1,'']]],
  ['classificacio_2ehh_2',['Classificacio.hh',['../_classificacio_8hh.html',1,'']]]
];
