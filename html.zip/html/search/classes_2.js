var searchData=
[
  ['jugador_0',['Jugador',['../class_jugador.html',1,'']]]
];
