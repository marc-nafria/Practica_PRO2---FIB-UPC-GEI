var searchData=
[
  ['empty_0',['empty',['../class_bin_tree.html#a74cda259ba5c25b8ee38ed4dc33e4fad',1,'BinTree']]],
  ['escriure_5farbres_1',['escriure_arbres',['../class_torneig.html#a15a87fcad3dcf2e8e25cfae2a96d13eb',1,'Torneig']]],
  ['escriure_5festadistiques_2',['escriure_estadistiques',['../class_jugador.html#a0beaa483a2c4608d6012adb1c457ade4',1,'Jugador']]],
  ['escriure_5franking_3',['escriure_ranking',['../class_torneig.html#aac89d36a6a9616c0c585d9b125c2d86a',1,'Torneig']]],
  ['establir_5fpunts_4',['establir_punts',['../class_classificacio.html#a861e0203f1dac9af26f3c5ee80264bb8',1,'Classificacio']]]
];
