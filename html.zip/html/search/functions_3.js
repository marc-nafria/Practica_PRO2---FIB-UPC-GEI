var searchData=
[
  ['empty_0',['empty',['../class_bin_tree.html#a74cda259ba5c25b8ee38ed4dc33e4fad',1,'BinTree']]],
  ['escriure_5festadistiques_1',['escriure_estadistiques',['../class_jugador.html#a0beaa483a2c4608d6012adb1c457ade4',1,'Jugador']]],
  ['establir_5fpunts_2',['establir_punts',['../class_classificacio.html#a861e0203f1dac9af26f3c5ee80264bb8',1,'Classificacio']]]
];
