var searchData=
[
  ['main_0',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['modificar_5farbre_5femparellaments_1',['modificar_arbre_emparellaments',['../class_torneig.html#a6d9f3946189e672630edb70cf04e81f0',1,'Torneig']]]
];
