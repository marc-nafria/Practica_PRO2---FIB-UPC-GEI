var searchData=
[
  ['nom_0',['nom',['../struct_categoria.html#ad39955d54081f0d7f31db96909a4f6bf',1,'Categoria']]]
];
