var searchData=
[
  ['practicà_20pro_202_3a_20gestió_20d_27un_20circuit_20de_20tennis_0',['Practicà Pro 2: Gestió d&apos;un circuit de Tennis',['../index.html',1,'']]]
];
