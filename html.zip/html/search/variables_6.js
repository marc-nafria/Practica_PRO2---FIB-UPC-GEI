var searchData=
[
  ['p_0',['p',['../class_bin_tree.html#afe3647af1dda90f6ddf1deee6560fcf1',1,'BinTree']]],
  ['partits_5fcontra_1',['partits_contra',['../struct_resultat.html#aca52912746cb59f55400107364a740c3',1,'Resultat::partits_contra()'],['../class_jugador.html#a44f625121f668c28cb1fcfa706ba1290',1,'Jugador::partits_contra()']]],
  ['partits_5ffavor_2',['partits_favor',['../struct_resultat.html#a9d84f0247214721722337d36720e1184',1,'Resultat::partits_favor()'],['../class_jugador.html#ae21c98b18aac779c71d0cd977557d1ea',1,'Jugador::partits_favor()']]],
  ['punts_3',['punts',['../struct_resultat.html#ab81e13e65ea0d122d6836a1cead8f242',1,'Resultat::punts()'],['../class_jugador.html#a438340e55baaec15ec14e854d646a37a',1,'Jugador::punts()']]],
  ['punts_5fper_5fnivell_4',['punts_per_nivell',['../struct_categoria.html#a73793e1a6f68e974972b0789f9a31e91',1,'Categoria']]]
];
