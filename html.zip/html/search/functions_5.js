var searchData=
[
  ['iniciar_5ftorneig_0',['iniciar_torneig',['../class_torneig.html#a0a12df5121f79dd97d43a7cbfd291ddf',1,'Torneig']]]
];
