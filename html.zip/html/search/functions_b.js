var searchData=
[
  ['torneig_0',['Torneig',['../class_torneig.html#a833b2f486a1648a8741d2115a9bb186c',1,'Torneig::Torneig()'],['../class_torneig.html#a98d476aced1063c8a0ff8e4d0d31b8da',1,'Torneig::Torneig(Categoria categoria_torneig)']]]
];
