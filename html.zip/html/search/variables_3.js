var searchData=
[
  ['jocs_5fcontra_0',['jocs_contra',['../struct_resultat.html#a551c20855cfd9ba38b23f5a36756606d',1,'Resultat::jocs_contra()'],['../class_jugador.html#aa2e394fec4426581e884bf7fe96cdefe',1,'Jugador::jocs_contra()']]],
  ['jocs_5ffavor_1',['jocs_favor',['../struct_resultat.html#afdbe10c31ea6c47c7f8d8465749c75c9',1,'Resultat::jocs_favor()'],['../class_jugador.html#ae123b3eb3aed8585a34272d9cc2bb70e',1,'Jugador::jocs_favor()']]],
  ['jugadors_2',['jugadors',['../class_classificacio.html#a0a77f27c0488b91895de66b276818b45',1,'Classificacio::jugadors()'],['../program_8cc.html#af06cd104b07890efd0af7b4a5ab8e84b',1,'jugadors():&#160;program.cc']]]
];
