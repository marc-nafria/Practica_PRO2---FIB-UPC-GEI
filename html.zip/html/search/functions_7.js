var searchData=
[
  ['left_0',['left',['../class_bin_tree.html#a82108db4c1b08d1f111027788c196d4e',1,'BinTree']]],
  ['llegir_5farbre_5fresultat_1',['llegir_arbre_resultat',['../class_torneig.html#a6a62c85f744db666f381ed5d58ae726f',1,'Torneig']]],
  ['llegir_5fpartit_2',['llegir_partit',['../class_torneig.html#a1fdb8f1635cc65316bee2b9865fb02ab',1,'Torneig']]]
];
