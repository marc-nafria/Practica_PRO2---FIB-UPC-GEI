var searchData=
[
  ['ranking_0',['ranking',['../class_jugador.html#abfd82fbfa2e58fdd634c94f7bc11c66b',1,'Jugador::ranking()'],['../class_torneig.html#a3d203da4e8b2dd80ee785f5702a525b4',1,'Torneig::ranking()'],['../program_8cc.html#a85d32da86b41760a67aaa338741896b8',1,'ranking():&#160;program.cc']]],
  ['ranking_5fpunts_1',['ranking_punts',['../class_torneig.html#aec970031f07d9cffbc21cec8f6b9dff8',1,'Torneig']]],
  ['right_2',['right',['../struct_bin_tree_1_1_node.html#a6df770137090da60cd0376ce06893cbd',1,'BinTree::Node']]]
];
