var searchData=
[
  ['retirar_5fresultat_0',['retirar_resultat',['../class_jugador.html#adf706a1f4a79da9495f47874c11810f5',1,'Jugador']]],
  ['right_1',['right',['../class_bin_tree.html#aff8e96651b27284c329667b5ad3e4d0b',1,'BinTree']]]
];
