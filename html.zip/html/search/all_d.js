var searchData=
[
  ['torneig_0',['Torneig',['../class_torneig.html',1,'Torneig'],['../class_torneig.html#a833b2f486a1648a8741d2115a9bb186c',1,'Torneig::Torneig()'],['../class_torneig.html#a98d476aced1063c8a0ff8e4d0d31b8da',1,'Torneig::Torneig(Categoria categoria_torneig)']]],
  ['torneig_2ehh_1',['Torneig.hh',['../_torneig_8hh.html',1,'']]],
  ['tornejos_2',['tornejos',['../program_8cc.html#a97a7fe13597b0ed2c30e80d9e0f74832',1,'program.cc']]]
];
