var searchData=
[
  ['jugador_0',['Jugador',['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador::Jugador()'],['../class_jugador.html#a7888f2833f55ff67626eea8469069839',1,'Jugador::Jugador(string nom, int ranking)'],['../class_jugador.html#a48a89d6fd87bec6abe759bdfc4490962',1,'Jugador::Jugador(const Jugador &amp;j)']]]
];
