var searchData=
[
  ['categoria_0',['Categoria',['../struct_categoria.html',1,'']]],
  ['classificacio_1',['Classificacio',['../class_classificacio.html',1,'']]]
];
