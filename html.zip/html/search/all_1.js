var searchData=
[
  ['bintree_0',['BinTree',['../class_bin_tree.html',1,'BinTree&lt; T &gt;'],['../class_bin_tree.html#a1408d37d1afda12d99747d09543c15f4',1,'BinTree::BinTree(shared_ptr&lt; Node &gt; p)'],['../class_bin_tree.html#a47eef22d29cd023449d97c073c08e5b6',1,'BinTree::BinTree()'],['../class_bin_tree.html#a1ab686e0bcf990093ff91fe71744c1a4',1,'BinTree::BinTree(const T &amp;x)'],['../class_bin_tree.html#adb7eeff76d08130c943b36af215eb521',1,'BinTree::BinTree(const T &amp;x, const BinTree &amp;left, const BinTree &amp;right)']]],
  ['bintree_2ehh_1',['BinTree.hh',['../_bin_tree_8hh.html',1,'']]],
  ['bintree_3c_20int_20_3e_2',['BinTree&lt; int &gt;',['../class_bin_tree.html',1,'']]],
  ['bintree_3c_20string_20_3e_3',['BinTree&lt; string &gt;',['../class_bin_tree.html',1,'']]],
  ['borrar_5fclassificacio_4',['borrar_classificacio',['../class_classificacio.html#a195ac9a0ea2b43d67122d17e121fc520',1,'Classificacio']]],
  ['borrar_5fjugador_5',['borrar_jugador',['../class_classificacio.html#a75f3ac772019e0e020c02f79de7a37f7',1,'Classificacio::borrar_jugador()'],['../class_torneig.html#ad05e7c87b8e338194582001a89e5c6aa',1,'Torneig::borrar_jugador()']]]
];
