var searchData=
[
  ['actualitzar_5franking_0',['actualitzar_ranking',['../class_jugador.html#a209b78b3ece7c6226f76998ffc0d85f7',1,'Jugador::actualitzar_ranking()'],['../program_8cc.html#a6ce38024ea91cb93dadad960fb7a08da',1,'actualitzar_ranking():&#160;program.cc']]],
  ['afegir_5fpartit_1',['afegir_partit',['../class_classificacio.html#a1164331a4fd08d20f2bb6e1ab2a85a5e',1,'Classificacio']]],
  ['afegir_5fresultat_2',['afegir_resultat',['../class_jugador.html#a62b77d189737a104bdb146ea0cac1e80',1,'Jugador']]]
];
