var searchData=
[
  ['ranking_0',['ranking',['../program_8cc.html#a85d32da86b41760a67aaa338741896b8',1,'program.cc']]]
];
