var searchData=
[
  ['resultat_0',['Resultat',['../struct_resultat.html',1,'']]]
];
