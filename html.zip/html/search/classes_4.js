var searchData=
[
  ['torneig_0',['Torneig',['../class_torneig.html',1,'']]]
];
