var searchData=
[
  ['arbre_5femparellaments_0',['arbre_emparellaments',['../class_torneig.html#af9fb24eeb2c5759c38f9bc184b5e981b',1,'Torneig']]],
  ['arbre_5fresultat_1',['arbre_resultat',['../class_torneig.html#a39c56244360d31c57321450d65120a80',1,'Torneig']]]
];
