var searchData=
[
  ['finalitzar_5ftorneig_0',['finalitzar_torneig',['../class_torneig.html#a13a2d58c29700e30a052ea2e6d9c833b',1,'Torneig']]]
];
