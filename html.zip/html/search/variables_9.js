var searchData=
[
  ['tornejos_0',['tornejos',['../program_8cc.html#a97a7fe13597b0ed2c30e80d9e0f74832',1,'program.cc']]],
  ['tornejos_5fdisputats_1',['tornejos_disputats',['../class_jugador.html#a32623d8c3cacd4cbbd0c926eb14cfd8e',1,'Jugador']]]
];
